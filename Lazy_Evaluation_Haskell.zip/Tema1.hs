module Tema1 (
        solveSimple,
        solveCosts
        ) where

import Data.Array
import Data.Ix

--functii care returneaza prima,a doua,respectiv a treia componenta a unui 3-tuplu
take1st ::(Int,Int,Int)->Int
take1st (x,_,_)=x
take2nd ::(Int,Int,Int)->Int
take2nd (_,x,_)=x
take3rd ::(Int,Int,Int)->Int
take3rd (_,_,x)=x

--functie care primeste 2 noduri si un graf(sub forma de lista de 3-tupluri cu proprietatile din enunt) si verifica
--daca exista muchie intre cele 2 noduri.Returneaza o pereche de forma (Bool,Int) cu corespondenta:
--daca exista muchie ->(True,n) ,unde n=lungimea muchiei dintre cele 2 noduri
--daca nu exista muchie ->(False,-1) 
contains :: Int->Int->[(Int,Int,Int)]->(Bool,Int) 
contains _ _ [] = (False,-1)
contains node1 node2 graf = let list = head graf in
							if ( (node1 == (take1st list) && node2 == (take2nd list) )|| (node1 == (take2nd list) && node2 == (take1st list) )) then (True,take3rd list) 
							else
								(contains node1 node2 (tail graf))


solveSimple ::(Int,[(Int,Int,Int)]) -> Maybe([Int],Int)
solveSimple (n,graf) = 
		let 
			bounds = ((1,1,0),(n,n,n))
			--array in care va fi tinuta matricea de adiacenta.
			adiacenta = listArray ((1,1),(n,n)) [contains i j graf | (i,j)<- range ((1,1),(n,n))]
			--array de 3 dimensiuni in care se va calcula costul minim dintre oricare 2 noduri
			--mat_cost!(i,j,k) = lungimea minima a unui drum avand extremitatile in i si j in care
			--orice nod intermediar din el e din multimea {1,2,...,k}
			--Se obtine relatia mat_cost!(i,j,k) = min(mat_cost!(i,j,k-1),mat_cost!(k,j,k-1)+mat_cost!(i,k,k-1))
			--unde mat_cost!(i,j,0) = lungimea muchiei (i,j) sau -1 daca nu exista
			mat_cost = listArray bounds [f_calcul i j k |(i,j,k)<-range bounds]

			f_calcul i j k
				| k==0 = if(i==j) then 0 else snd (adiacenta ! (i,j))
				| i>j = mat_cost!(j,i,k)
				| otherwise = let x =  mat_cost!(i,j,k-1) in
							  let y =  mat_cost!(i,k,k-1) in
							  let z =  mat_cost!(k,j,k-1) in
							  if(x== -1 && (y== -1|| z== -1)) then -1
							  else if(x== -1) then y+z
							  else if (y== -1|| z== -1) then x
							  else min x (y+z)

			--functie de reconstructie a drumului				  
			afisare n k = 	if (k == 1 && n ==1) then [n]
							else if(k==1) then [n,1]
							else 
							   	let l = map (\(i,j) -> let  x=mat_cost!(1,i,j) in
							   						   let 	y=snd (adiacenta!(i,n)) in
							   								if(x == -1 || y == -1) then -1
							   								else x+y) (range ((1,1),(n-1,k))) 
								in
										--luam prima pozitie din lista perechilor cu cea de a 2a componenta egala cu mat_cost!(1,n,k)
										--unde acea componenta a fost calculata mai sus in lista l
										let pozitie =[fst x | x<-zip (range ((1,1),(n-1,k))) l , snd x == mat_cost!(1,n,k)]!!0 in
										n:(afisare (fst pozitie) (snd pozitie))
		
			drum = reverse(afisare n n)
		
		in 
		--daca mat_cost!(1,n,n) == -1 inseamna ca nu avem niciun drum de la 1 la n.
		--Altfel,returnam drumul de lungime minima alaturi de lungimea acestuia
			if(mat_cost!(1,n,n) == -1) then Nothing else Just (drum,mat_cost!(1,n,n))
		


solveCosts ::(Int,Int,[Int],[(Int,Int,Int)])-> Maybe ([(Int,Int)],Int)
solveCosts (n,sum,costs,graf) =
		let 
			bounds = ((0,1,1),(sum,n,n))
			
			--array in care va fi tinuta matricea de adiacenta.
			adiacenta = listArray ((1,1),(n,n)) [contains i j graf | (i,j)<- range ((1,1),(n,n))]
			
			--matricea de programare dinamica.
			--dp!(k,i,j) = lungimea minima a drumului minim dintre i si j in care avem la dispozitie cel mult suma k
			--dp!(k,i,j) = min(adiacenta!(i,index)+dp!(k-cost!index,index,j)),atunci cand index parcurge multimea 
			--{1,2,...,n} astfel incat sa existe muchia (i,index),costul de intrare in nodul index sa fie mai mic sau egal 
			--decat suma k ,iar dp!(k-cost!index,index,j) sa fie diferit de -1(adica sa se poata ajunge de la index la j)
			dp = listArray bounds [g_calcul k i j | (k,i,j)<-range bounds]
			

			--array in care se retin costurile de intrare in fiecare oras
			cost = listArray (1,n) [ costs!!i | i<-[0..(n-1)]]
			

			--matricea in care se retine costul necesar pentru a obtine drumurile minime
			--cost_minim!(k,i,j) = costul necesar pentru a obtine drumul de lungime dp!(k,i,j) dintre i si j
			cost_minim = listArray bounds [ head [index | index<-[0..k],dp!(index,i,j) == dp!(k,i,j)] | (k,i,j)<-range bounds]

			--functia care calculeaza matricea --datorita evaluari lenese fiecare apel se va executa o singura data
			g_calcul k i j
				--daca i==j punem 0,altfel daca k==0 punem -1,altfel
				| i==j = 0
				| k==0 = -1
			 	| otherwise = let list = map (\index -> if (i==index || fst (adiacenta!(i,index)) == False || k < (cost!index) || dp!(k - (cost!index),index,j) == -1) then -1
			 											else (snd (adiacenta!(i,index))) + dp!(k - (cost!index),index,j) ) [1..n]
			 				  in    
			 				  --separam in 2 liste lista ,l1 in care avem doar elementele egale cu -1 si l2 in care avem elementele diferite de -1
			 				  let l1 = [ x | x<-list,x == -1] in
			 				  let l2 = [ x | x<-list, x/= -1] in
			 				  --daca avem doar -1 in list completam cu -1 deoarece nu putem alege niciun nod in care sa ne deplasam
			 				  if( length l1 == length list) then -1
			 				  --altfel,luam minimul din multimea l1 
			 				  else (minimum l2)

			--functie  de "reconstructie " a drumului minim de cost minim
			afisare poz_curenta s 
						--daca am ajuns la pozitia finala returnam perechea (n,s)
						| poz_curenta==n = [(poz_curenta,s)]
						--altfel,creem list care va avea pe pozitia i fie -1(atunci cand nu pot sa ma duc de la nodul curent la i fie pentru ca nu am muchie fie pentru ca
						--costul de intrare e prea mare ori pentru ca nu exista drum de la index la nodul n),fie lungimea drumului de la pozitia curenta la index +
						--lungimea drumului minim dintre index si n,in care suma curenta se modifica cu costul de intrare in nodul index.
			 			| otherwise = let list = map (\index -> if( poz_curenta==index || fst (adiacenta!(poz_curenta,index)) == False || s < (cost!index) || dp!(s - (cost!index),index,n) == -1) then -1
			 													else (snd (adiacenta!(poz_curenta,index))) + dp!(s - (cost!index),index,n) ) [1..n] 
			 						  in
			 						  --grupam in perechi de forma (index,x)-unde x e valoare obtinuta prin incercarea de a trece de la pozitie_curenta la nodul index,
			 						  --eliminand toate perechile care au a prima componenta -1 (adica cele la care nu putem ajunge)
			 						  let l1 = [(x,i) | (x,i)<- zip list [1..n] , x/= -1 ] in
			 						  --formam l2 care va contine toate perechile pentru care se poate obtine minimul din l1 dupa prima componenta
			 						  let l2 = [ (x,i) | (x,i)<- l1 , x == fst (minimum l1)   ] in 
			 						  --pentru fiecare astfel de pereche,calculam care este costul minim 
			 						  let l3 = [ (cost!i + cost_minim!(s-cost!i,i,n) ,i) | (x,i)<- l2] in
			 						  --alegem cel mai mic cost
			 						  let next_poz = snd (minimum l3) in
			 						  (poz_curenta,s):(afisare next_poz (s-cost!next_poz))
								 						  					 	  
		in  
			--daca lungimea celui mai scurt drum e negativa inseamna ca returnam Nothing
			if(dp!(sum,1,n) < 0) then Nothing 
				--altfel,returnam drumul de lungime minima avand suma sum ,alaturi de lungimea sa
			else 
				let l = afisare 1 sum in 
				Just (l,dp!(sum,1,n))
